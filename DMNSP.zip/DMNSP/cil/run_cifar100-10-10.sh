#!bin/bash

python main.py \
    --config-path /DMNSP/cil/configs/class \
    --config-name cifar100_10-10.yaml \
    dataset_root="/data/**/" \
    class_order="/DMNSP/cil/class_orders/cifar100.yaml"



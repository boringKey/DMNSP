simple_template = [
    lambda c: f"a photo of a {c}."
]